void mostrarProducto();
void mostrarColores();
void mostrarTallas();
void mostrarDisponibilidad(int producto, int color, int talla);
int leerEntero(const char* mensaje);


